
const convertStringToUppercase = {
    getStringInUpperCase: (stringABC) => {
      return stringABC.toUpperCase();
    }
  }
  module.exports = {
    convertStringToUppercase
  }