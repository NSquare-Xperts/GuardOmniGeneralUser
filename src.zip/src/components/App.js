import React from 'react';
import { View } from 'react-native';

const App =() => {

    return(
        <View />
    );
}
export default App;