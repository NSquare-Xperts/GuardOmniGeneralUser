import React, { Component } from 'react'
import AddComplaintInput from './AddComplaintInput';

class AddComplaint extends Component {
  render() {    
       return( 
            // <AddVisiorRequestInput/>
          //   <AddVisiorRequestInput/>
          <AddComplaintInput/>
       )
  }
}
export default AddComplaint;

