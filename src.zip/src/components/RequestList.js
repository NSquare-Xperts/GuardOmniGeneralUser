import React, { Component } from 'react';


class RequestList extends Component{
    render(){
    return(
       <ViEW></ViEW>
    )
    }
}
export default RequestList;