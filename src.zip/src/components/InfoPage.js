import React, { Component } from 'react';
import { FullScreenImage } from './common/FullScreenImage';

//Class component : 1. used for presenting dyanamic 
                  // 2.Handle any data that may going to change
class InfoPage extends Component {
    render(){
        return (
             <FullScreenImage/>
         );
    }
}
export default InfoPage;