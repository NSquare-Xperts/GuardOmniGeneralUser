import React,{ Component } from 'react';
import { Text,View} from 'react-native'


class SideMenu extends Component {
render(){
return(
    <View>
            <Text> HIIIIII SIDE MENU</Text>
    </View>
    ); 
  }
}
export default SideMenu;
