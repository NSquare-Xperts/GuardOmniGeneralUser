export const white_Original = '#FFFFFF';
export const white_light = '#CCFFFFFF';
export const black = '#212121';
export const grey = '#5C5C5C';
export const grey_light = '#5C5C5C';
export const grey_lighter = '#995C5C5C';
export const purple = '#BC49FF';
export const pink = '#FF5F95'
export const orange = '#FF8F39'
export const blue = '#581BFE'
export const red = '#D60606'
export const red_lighter = '#FFF7F7'
export const green = '#06D6A0'
export const green_select = '#06B587'
export const green_fluorescent = '#23D606'
export const light_blue = '#1BACFE'


