import React, { Component } from 'react'
import AddManualInInput from './common/AddManualInInput';

class GuardAddVisitorRequest extends Component {
  render() {    
       return( 
             <AddManualInInput/>
       )
  }
}
export default GuardAddVisitorRequest;

