import React, { Component } from 'react'
import EditProfileInput from './EditProfileInput'
//import { DecisionAlert } from './common/DecisionAlert';

class EditProfile extends Component {
  render() {    
       return( 
            // <AddVisiorRequestInput/>
             <EditProfileInput/>
          
       )
  }
}
export default EditProfile;

