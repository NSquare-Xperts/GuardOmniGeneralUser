import Data from './codes.json';

export default () => Data;